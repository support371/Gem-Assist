#!/usr/bin/env python3
"""
Simple backend server for GEM integration on Replit.

This server is designed as a lightweight HTTP API that handles webhook events
from Telegram and Make.com and retrieves content from a Notion database. It
reads configuration from environment variables so that secrets can be stored
securely using Replit's Secrets tool.  You can run this server on Replit
without any external dependencies beyond the standard library and the
requests library, which is available in this environment.

Environment variables:
  NOTION_DATABASE_ID:       ID of the Notion database to query for content
  NOTION_INTEGRATION_SECRET: Notion internal integration secret
  TELEGRAM_BOT_TOKEN:        Token for your Telegram bot (if needed)
  TELEGRAM_CHANNEL_ID:       Telegram channel ID (if needed)
  PORT:                      Port number for the HTTP server (default 8000)

Endpoints:
  GET /notion                Query the Notion database and return entries as JSON
  POST /telegram/webhook     Accept webhook updates from Telegram
  POST /make/webhook         Accept webhook triggers from Make.com

This code is intentionally simple to illustrate the core integration points.
Further business logic—such as verifying signatures, processing updates, or
formatting responses—should be added based on your application's needs.
"""

import json
import os
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse
import requests


# Read configuration from environment variables
NOTION_DATABASE_ID = os.environ.get("NOTION_DATABASE_ID")
NOTION_INTEGRATION_SECRET = os.environ.get("NOTION_INTEGRATION_SECRET")
TELEGRAM_BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN")
TELEGRAM_CHANNEL_ID = os.environ.get("TELEGRAM_CHANNEL_ID")


def query_notion_database():
    """Query the Notion database and return the raw JSON response.

    Returns an empty dict if required configuration is missing or a request
    error occurs. This function uses the Notion REST API to fetch entries
    from a specified database. You can customize the payload to filter or
    sort entries as needed.
    """
    if not NOTION_DATABASE_ID or not NOTION_INTEGRATION_SECRET:
        return {"error": "Notion configuration missing"}
    url = f"https://api.notion.com/v1/databases/{NOTION_DATABASE_ID}/query"
    headers = {
        "Authorization": f"Bearer {NOTION_INTEGRATION_SECRET}",
        # Notion version header is required; update it as appropriate
        "Notion-Version": "2022-06-28",
        "Content-Type": "application/json",
    }
    try:
        resp = requests.post(url, headers=headers, json={})
        resp.raise_for_status()
        return resp.json()
    except Exception as exc:
        # In production, log the exception to monitoring/telemetry
        return {"error": f"Failed to query Notion: {exc}"}


class SimpleHTTPRequestHandler(BaseHTTPRequestHandler):
    """Custom HTTP request handler supporting JSON endpoints."""

    def _set_response(self, status=200, content_type="application/json"):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        # Allow CORS for development; restrict in production
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()

    def log_message(self, format: str, *args) -> None:
        """Override default logging to reduce noise or integrate with logging framework."""
        # Print to stdout; in real deployments, integrate with structured logging
        print(f"{self.client_address[0]} - {format % args}")

    def do_OPTIONS(self):
        """Handle CORS preflight requests."""
        self.send_response(200)
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()

    def do_GET(self):
        """Serve GET requests for the Notion endpoint."""
        parsed_path = urlparse(self.path)
        if parsed_path.path == "/notion":
            data = query_notion_database()
            self._set_response()
            self.wfile.write(json.dumps(data).encode())
        else:
            self._set_response(status=404)
            self.wfile.write(json.dumps({"error": "Not found"}).encode())

    def do_POST(self):
        """Serve POST requests for Telegram and Make webhooks."""
        content_length = int(self.headers.get("Content-Length", 0))
        body_bytes = self.rfile.read(content_length)
        try:
            body = json.loads(body_bytes) if body_bytes else {}
        except json.JSONDecodeError:
            body = {}
        if self.path == "/telegram/webhook":
            # Handle Telegram webhook updates here
            # For example, you could parse commands and send responses via the Telegram bot API
            print("Received Telegram update:", body)
            self._set_response(200)
            self.wfile.write(json.dumps({"status": "ok"}).encode())
        elif self.path == "/make/webhook":
            # Handle Make.com webhook events here
            print("Received Make.com webhook:", body)
            self._set_response(200)
            self.wfile.write(json.dumps({"status": "ok"}).encode())
        else:
            self._set_response(status=404)
            self.wfile.write(json.dumps({"error": "Not found"}).encode())


def run_server():
    """Start the HTTP server. Use PORT environment variable or default to 8000."""
    port = int(os.environ.get("PORT", "8000"))
    server_address = ("", port)
    httpd = HTTPServer(server_address, SimpleHTTPRequestHandler)
    print(f"Starting backend server on port {port}...")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("Server interrupted, shutting down.")
    httpd.server_close()


if __name__ == "__main__":
    run_server()