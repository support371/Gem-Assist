# GEM Replit Backend

This directory contains a minimal Python backend designed to integrate the GEM Cybersecurity platform with Replit.  The server uses Python’s built‑in `http.server` module to expose lightweight API endpoints and the `requests` library (already available in this environment) to communicate with external services such as Notion.  You can run this backend locally or deploy it on Replit using the instructions below.

## Project Structure

| File | Purpose |
| --- | --- |
| `server.py` | Main entry point for the backend. It sets up an HTTP server with endpoints for Notion content retrieval (`GET /notion`) and webhook handlers for Telegram (`POST /telegram/webhook`) and Make.com (`POST /make/webhook`). |
| `README.md` | Provides setup and deployment instructions. |

## Requirements

* Python 3.7 or higher
* [`requests` library](https://docs.python-requests.org/) (installed by default in this environment)

## Running Locally

1. Ensure that the necessary environment variables are set in your shell:

   ```bash
   export NOTION_DATABASE_ID=your_notion_database_id
   export NOTION_INTEGRATION_SECRET=your_notion_secret
   export TELEGRAM_BOT_TOKEN=your_telegram_bot_token  # optional
   export TELEGRAM_CHANNEL_ID=your_telegram_channel_id  # optional
   export PORT=8000
   ```

2. From the `replit-backend` directory, run the server:

   ```bash
   python server.py
   ```

3. The server will start on the specified `PORT` (default 8000).  You can test the Notion endpoint with `curl`:

   ```bash
   curl http://localhost:8000/notion
   ```

## Deploying on Replit

To deploy this backend on Replit:

1. **Create a new Replit app:** Log into Replit and create a new Python app.  Name it something like `gem-backend` and choose Python as the language.

2. **Upload the project files:** Add the contents of the `replit-backend` directory (including `server.py` and `README.md`) to your Replit project.  You can do this by dragging and dropping the files into the Replit file tree or by cloning a Git repository containing these files.

3. **Set environment variables:** Use Replit’s **Secrets** tool to securely store your API keys and configuration.  Navigate to the **Secrets** tab in Replit’s workspace and add the following keys and values:

   * `NOTION_DATABASE_ID` – ID of your Notion database
   * `NOTION_INTEGRATION_SECRET` – Notion internal integration secret
   * `TELEGRAM_BOT_TOKEN` – Telegram bot token (if handling Telegram webhooks)
   * `TELEGRAM_CHANNEL_ID` – Telegram channel ID (if needed)
   * `PORT` – Port number to run the server (e.g., `8000`)

   These secrets will be available to your code via `os.environ`.

4. **Configure the run command:** Edit the `.replit` file (or use the **Nix** builder) to specify the command used to start your server.  For a simple Python app, your `.replit` file should contain something like:

   ```
   run = "python server.py"
   ```

5. **Start the app:** Click the **Run** button in Replit.  The server will start and your endpoints will be accessible at `https://<your-repl>.repl.co/notion`, `/telegram/webhook`, and `/make/webhook`.

## Extending the Backend

This skeleton is intentionally minimal.  To build a production‑ready backend, consider:

* **Validating and authenticating webhook requests** from Telegram and Make.com.
* **Implementing command parsing** and response logic within the Telegram webhook handler.
* **Filtering and formatting Notion data** before returning it to the client.
* **Adding additional endpoints** for asset recovery workflows, real‑estate management, or user authentication.
* **Integrating a database** (e.g., SQLite or Replit’s built‑in database) to store state or client data.

Use this foundation as a starting point to build a secure and scalable backend that supports GEM’s multifaceted services.
